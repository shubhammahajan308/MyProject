import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
//import { HomeComponent } from './home/home.component';
import { HomeComponent } from './home/home.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { FeaturesComponent } from './features/features.component';
import { UploadPageComponent } from './upload-page/upload-page.component';

const routes: Routes = [{
  path: 'home', component: HomeComponent,
  children: [
    { path: 'about-us', component: AboutUsComponent },
    { path: 'features', component: FeaturesComponent },
    { path: 'upload-page', component: UploadPageComponent }]
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
